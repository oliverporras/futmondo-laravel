

<?php $__env->startSection('content'); ?>
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Noticias">Noticias</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="<?php echo e(url('/home')); ?>"> <i class="fas fa-home"></i> Inicio </a> </li>
            <li> <a href=".#" class="active"> Noticias </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content innerpagebg wf100 p80">
        <!--News Large Page Start--> 
        <!--Start-->
        <div class="news-large">
          <div class="container">
            <div class="row">
              <!--News Start-->
              <div class="col-lg-8">
                <div class="news-wrap">
                  <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Post Start-->
                    <div class="news-large-post">
                      <?php if(isset($noticia->imagen)): ?>  
                        <div class="post-thumb"> <a href="../noticias/<?php echo e($noticia->id); ?>"><i class="fas fa-link"></i></a> <img src="../images/news/<?php echo e($noticia->imagen); ?>" alt=""></div>
                      <?php endif; ?>
                      <div class="post-txt">
                        <h3><a href="../noticias/<?php echo e($noticia->id); ?>"><?php echo e($noticia->titulo); ?></a></h3>
                        <ul class="post-meta">
                          <li><i class="fas fa-calendar-alt"></i> <?php echo e($noticia->fecha); ?></li>
                        </ul>
                        <p><?php echo e($noticia->subtitulo); ?></p>
                        <a href="../noticias/<?php echo e($noticia->id); ?>" class="rm">Leer más</a> 
                      </div>
                    </div>
                    <!--Post End-->                    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

                  <div class="gt-pagination">
                    <nav aria-label="Page navigation example">
                      <ul class="pagination justify-content-center">
                        <?php if( !$noticias->onFirstPage() ): ?>
                        <li class="page-item"> <a class="page-link" href="<?php echo e($noticias->previousPageUrl()); ?>" tabindex="-1" aria-disabled="true"><i class="fas fa-angle-left"></i></a> </li>
                        <?php endif; ?>
                        <li class="page-item active"><a class="page-link" href="../noticias?page=<?php echo e($noticias->currentPage()); ?>"><?php echo e($noticias->currentPage()); ?></a></li>
                        <?php if( $noticias->currentPage() < $noticias->lastPage() ): ?>
                        <li class="page-item"> <a class="page-link" href="<?php echo e($noticias->nextPageUrl()); ?>"><i class="fas fa-angle-right"></i></a> </li>
                        <?php endif; ?>
                      </ul>
                    </nav>
                  </div>
                </div>
              </div>
              <!--News End--> 
              <!--Sidebar Start-->
              <div class="col-lg-4">
                <div class="sidebar">
                  <!--widget start-->
                  <div class="widget">
                    <h4>Clasificación</h4>
                    <div class="point-table-widget">
                      <table>
                        <thead>
                          <tr>
                            <th title="Posición">P</th>
                            <th>Equipo</th>
                            <th title="Jornadas">J</th>
                            <th>Pts</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($equipo->Puesto); ?></td>
                            <td class="tn"><strong><?php echo e($equipo->Nombre); ?></strong></td>
                            <td><?php echo e($equipo->Jornadas); ?></td>
                            <td><strong><?php echo e($equipo->Puntos); ?></strong></td>
                          </tr>                          
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <!--widget end--> 
                  <!--widget start-->
                  <div class="widget">
                    <h4>Sponsors</h4>
                    <ul class="match-sponsors">
                      <li> <a href="https:sticker4life.com" target="_blank"><img src="../images/sticker4life.png" alt=""></a> </li>
                      <!--<li> <a href="#"><img src="images/sitelogos2.png" alt=""></a> </li>
                      <li> <a href="#"><img src="images/sitelogos3.png" alt=""></a> </li>
                      <li> <a href="#"><img src="images/sitelogos4.png" alt=""></a> </li>
                      <li> <a href="#"><img src="images/sitelogos5.png" alt=""></a> </li>
                      <li> <a href="#"><img src="images/sitelogos6.png" alt=""></a> </li>-->
                    </ul>
                  </div>
                  <!--widget end--> 

                </div>
              </div>
              <!--Sidebar End--> 
            </div>
          </div>
        </div>
        <!--End--> 
      </div>
      <!--Main Content End--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/news.blade.php ENDPATH**/ ?>