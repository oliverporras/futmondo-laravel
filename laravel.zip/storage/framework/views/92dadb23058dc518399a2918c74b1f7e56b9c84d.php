<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../images/fav.png" type="image/png">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/custom.css">
    <link rel="stylesheet" href="../css/responsive.css">
    <link rel="stylesheet" href="../css/color.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/fontawesome.css">
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/prettyPhoto.css">
    <title><?php echo e(config('app.name', 'Futmondo Sage')); ?></title>

    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>
<body>
    <!--Wrapper Start-->
    <div class="wrapper">
        <!--Header Start-->
        <header id="main-header" class="main-header">

            <!--Logo + Navbar Start-->
            <div class="logo-navbar">
                <div class="container">
                    <div class="row">
                        <div class="col-md-2 col-sm-5">
                            <div class="logo"><a href="../home"><img src="../images/ftmndLogo.png" alt=""></a></div>
                        </div>
                        <div class="col-md-10 col-sm-7">
                            <nav class="main-nav">
                                <ul>
                                    <li class="nav-item drop-down">
                                        <a href="<?php echo e(url('/home')); ?>">Inicio</a>
                                    </li>
                                    <li class="nav-item drop-down">
                                        <a href="<?php echo e(url('/equipos')); ?>">Equipos</a>
                                        <ul>
                                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a style="line-height: 30px;" href="<?php echo e(url('/equipo')); ?>/<?php echo e($team->Id); ?>"><?php echo e($team->Nombre); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    <li class="nav-item drop-down">
                                        <a href="<?php echo e(url('/entrenadores')); ?>">Entrenadores</a>
                                        <ul>
                                            <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a style="line-height: 30px;" href="<?php echo e(url('/entrenador')); ?>/<?php echo e($coach->Id); ?>"><?php echo e($coach->Entrenador); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                    <li class="nav-item drop-down">
                                        <a href="<?php echo e(url('/noticias')); ?>">Noticias</a>
                                    </li>
                                    <li class="nav-item drop-down">
                                        <a href="">Otras temporadas</a>
                                        <ul>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/21">Temporada 21-22</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/20">Temporada 20-21</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/19">Temporada 19-20</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/18">Temporada 18-19</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/C18">Temporada 18-19 Cartagena</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/17">Temporada 17-18</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/C17">Temporada 17-18 Cartagena</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/16">Temporada 16-17</a></li>
                                            <li><a href="<?php echo e(url('/temporada')); ?>/15">Temporada 15-16</a></li>
                                        </ul>
                                    </li>
                                    <li class="nav-item drop-down">
                                        <a href="../contact.html">Contacto</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <!--Logo + Navbar End--> 
        </header>
        <!--Header End--> 
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!--Main Footer Start-->
        <footer class="wf100 main-footer">
            <div class="container brtop">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <p class="copyr"> All Rights Reserved of Sports © 2020, Design & Developed By: <a href="oliverporras.com">OliverPorras</a> </p>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <ul class="quick-links">
                            <li><a href="<?php echo e(url('/home')); ?>">Inicio</a></li>
                            <li><a href="<?php echo e(url('/equipos')); ?>">Equipos</a></li>
                            <li><a href="<?php echo e(url('/entrenadores')); ?>">Entrenadores</a></li>
                            <li><a href="<?php echo e(url('/noticias')); ?>">Noticias</a></li>
                            <li><a href="<?php echo e(url('/contacto')); ?>">Contacto</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!--Main Footer End--> 
    </div>
    <!--Wrapper End--> 
    <!-- Optional JavaScript --> 
    <script src="../js/jquery-3.3.1.min.js"></script> 
    <script src="../js/popper.min.js"></script> 
    <script src="../js/bootstrap.min.js"></script> 
    <script src="../js/mobile-nav.js"></script>  
    <script src="../js/owl.carousel.min.js"></script> 
    <script src="../js/isotope.js"></script> 
    <script src="../js/jquery.prettyPhoto.js"></script> 
    <script src="../js/jquery.countdown.js"></script> 
    <script src="../js/custom.js"></script>
</body>
</html><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>