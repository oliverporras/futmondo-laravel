

<?php $__env->startSection('content'); ?>
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Otras Temporadas">Otras Temporadas</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="<?php echo e(url('/home')); ?>"> <i class="fas fa-home"></i> Inicio </a> </li>
            <?php 
            $Temporada = substr($id,-2);

            ?>
            <li> <a href="#" class="active"> Temporada <?php echo e($Temporada); ?>-<?php echo e($Temporada+1); ?></a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content solidbg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
          <!--Start-->
          <div class="point-table">
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                  <div class="point-table-widget">
                    <table>
                      <thead>
                        <tr>
                          <th>Pos</th>
                          <th>Equipo</th>
                          <th>Entrenador</th>
                          <th>Puntos</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($equipo->rn); ?></td>
                          <td>
                            <?php if($equipo->Escudo): ?>
                            <img class="escudo-fit" src="../images/teams/<?php echo e($equipo->Escudo); ?>" onerror="this.src='../images/tl-logo1.png';" alt="<?php echo e($equipo->Nombre); ?>"> <strong><?php echo e($equipo->Nombre); ?></strong>
                            <?php else: ?>
                            <img class="escudo-fit" src="../images/tl-logo1.png" alt="<?php echo e($equipo->Nombre); ?>"> <strong><?php echo e($equipo->Nombre); ?></strong>
                            <?php endif; ?>
                          </td>
                          <td>
                            
                            <?php if($equipo->Foto): ?>
                            <img class="user-list" src="../fotos/<?php echo e($equipo->Foto); ?>"  onerror="this.src='../fotos/user.png';" alt="<?php echo e($equipo->Entrenador); ?>">
                            <?php endif; ?>
                            <strong><?php echo e($equipo->Entrenador); ?></strong>
                          </td>
                          <td><strong><?php echo e($equipo->Ptos); ?></strong></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--End--> 
        </div>
        <!--team Page End--> 
      </div>
      <!--Main Content End--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/season.blade.php ENDPATH**/ ?>