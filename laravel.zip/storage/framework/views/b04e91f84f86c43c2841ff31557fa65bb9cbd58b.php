

<?php $__env->startSection('content'); ?>

      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Entrenadores">Entrenadores</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="<?php echo e(url('/home')); ?>"> <i class="fas fa-home"></i> Inicio </a> </li>
            <li> <a href="#" class="active"> Entrenadores </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content innerpagebg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
          <!--Start-->
          <div class="player-squad">
            <div class="container">
              <div class="row">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <!--Player Box Start-->
                  <div class="col-md-6">
                    <div class="player-box">
                      <?php if($team->Foto): ?>
                      <div class="player-thumb"> <img class="resize_fit_center" src="../fotos/<?php echo e($team->Foto); ?>" alt="<?php echo e($team->Entrenador); ?>"></div>
                      <?php endif; ?>
                      <div class="player-txt">
                        <!--<div class="num"><?php echo e($team->getRanking()); ?></div>-->
                        <div class="num"><?php echo e($team->Ptos); ?></div>
                        <h3><?php echo e($team->Nombre); ?></h3>
                        <strong class="player-desi"><?php echo e($team->Entrenador); ?></strong>
                        <?php if(isset($team->Lema)): ?>
                        <p> <?php echo e($team->Lema); ?> </p>
                        <?php endif; ?>
                        <!--<ul>
                          <li>29 <span>Age</span></li>
                          <li>87 <span>matches</span></li>
                          <li>113 <span>Goals</span></li>
                          <li>87 <span>matches</span></li>
                        </ul>-->
                        <a class="playerbio" href="../jugador/<?php echo e($team->Id); ?>">Ficha del jugador <i class="far fa-arrow-alt-circle-right"></i></a> 
                      </div>
                    </div>
                  </div>
                  <!--Player Box End--> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
          <!--End--> 
        </div>
        <!--team Page End--> 
      </div>
      <!--Main Content End--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/coachlist.blade.php ENDPATH**/ ?>