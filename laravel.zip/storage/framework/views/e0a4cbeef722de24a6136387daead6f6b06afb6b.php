

<?php $__env->startSection('content'); ?>
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Clasificación">Clasificación</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="<?php echo e(url('/home')); ?>"> <i class="fas fa-home"></i> Inicio </a> </li>
            <li> <a href="#"  class="active"> Clasificación </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content solidbg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
          <!--Start-->
          <div class="point-table">
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                  <div class="point-table-widget">
                    <table>
                      <thead>
                        <tr>
                          <th>Pos</th>
                          <th>Equipo</th>
                          <th>Entrenador</th>
                          <th>Partidos</th>
                          <th>G</th>
                          <th>E</th>
                          <th>P</th>
                          <th>Puntos</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($equipo->Puesto); ?></td>
                          <td>
                            <?php if($equipo->Escudo): ?>
                            <img class="escudo-fit" src="../images/teams/<?php echo e($equipo->Escudo); ?>" alt="<?php echo e($equipo->Nombre); ?>"> <strong><a href="../equipo/<?php echo e($equipo->Id); ?>"><?php echo e($equipo->Nombre); ?></a></strong>
                            <?php else: ?>
                            <img class="escudo-fit" src="../images/tl-logo1.png" alt="<?php echo e($equipo->Nombre); ?>"> <strong><a href="../equipo/<?php echo e($equipo->Id); ?>"><?php echo e($equipo->Nombre); ?></a></strong>
                            <?php endif; ?>
                          </td>
                          <td>
                            <a href="../entrenador/<?php echo e($equipo->Id); ?>">
                            <?php if($equipo->Foto): ?>
                            <img class="user-list" src="fotos/<?php echo e($equipo->Foto); ?>" alt="<?php echo e($equipo->Entrenador); ?>">
                            <?php endif; ?>
                            <strong><?php echo e($equipo->Entrenador); ?></strong></a>
                          </td>
                          <td><?php echo e($equipo->Jornadas); ?></td>
                          <td><?php echo e($equipo->Victorias); ?></td>
                          <td><?php echo e($equipo->Empates); ?></td>
                          <td><?php echo e($equipo->Derrotas); ?></td>
                          <td><strong><?php echo e($equipo->Puntos); ?></strong></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--End--> 
        </div>
        <!--team Page End--> 
      </div>
      <!--Main Content End--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/home.blade.php ENDPATH**/ ?>