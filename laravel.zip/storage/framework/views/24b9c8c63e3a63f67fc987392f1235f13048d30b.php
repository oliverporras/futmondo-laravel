

<?php $__env->startSection('content'); ?>

      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Ficha de Entrenador">Ficha de Equipo</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="/home"> <i class="fas fa-home"></i> Inicio </a> </li>
            <li> <a href="/equipos"> Equipos </a> </li>
            <li> <a href="#"  class="active"> Ficha </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content innerpagebg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
          <!--Start-->
          <div class="player-squad">
            <div class="container">
              <div class="row">
                <!--Squad Start-->
                <div class="col-lg-8">
                  <!--Player Box Start-->
                  <div class="player-card">
                    <div class="pimg">
                      <?php if($team->Escudo): ?>
                      <img class="resize_escudo_center" src="../images/teams/<?php echo e($team->Escudo); ?>" alt="<?php echo e($team->Nombre); ?>">
                      <?php else: ?>
                      <img class="resize_escudo_center" src="../images/team.webp" alt="">
                      <?php endif; ?>
                      
                    </div>
                    <div class="player-details">
                      <h2><?php echo e($team->Nombre); ?></h2>
                      <?php $__currentLoopData = $from; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desde): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <strong class="desi">*Desde <?php echo e($desde->temporada); ?></strong>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <span class="follow"><a href="#">Temporada 22-23</a></span>
                      <ul>
                        <li> Entrenador <strong><a href="../entrenador/<?php echo e($team->Id); ?>"><?php echo e($team->Entrenador); ?></a></strong></li>
                        <li> Posición actual <strong><?php echo e($current_season->Puesto); ?></strong></li>
                        <li> Jugados <strong><?php echo e($current_season->Jornadas); ?></strong></li>
                        <li> Ganados <strong><?php echo e($current_season->Victorias); ?></strong></li>
                        <li> Empates <strong><?php echo e($current_season->Empates); ?></strong></li>
                        <li> Perdidos <strong><?php echo e($current_season->Derrotas); ?></strong></li>
                        <li> Puntos <strong><?php echo e($current_season->Puntos); ?></strong></li>
                      </ul>
                    </div>
                  </div>
                  <!--Player Box End--> 
                  <?php if(isset($team->Lema)): ?>
                  <!--Player Biography Start-->
                  <div class="player-bio">
                    <h4>Historia</h4>
                    <div class="txt">
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</p>
                      <blockquote> <?php echo e($team->Lema); ?> </blockquote>
                      <p> Sunt in culpa qui officia deserunt mollit anim id est laborum. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur. Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat. </p>
                    </div>
                  </div>
                  <!--Player Biography End--> 
                  <?php endif; ?>

                  <!--Career Facts Start-->
                  <div class="career-facts">
                    <h4>Palmarés</h4>
                    <table>
                      <thead>
                        <tr>
                          <th>Temporada</th>
                          <th>Campeonato</th>
                          <th>Posición</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $team_facts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($fact->temporada); ?></td>
                          <td><?php echo e($fact->campeonato); ?></td>
                          <td>
                            <?php if($fact->puesto == 1 ): ?>
                              <i class="fa fa-trophy"></i>
                            <?php endif; ?>
                            <?php echo e($fact->puesto); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                  <!--Career Facts End--> 
                </div>
                <!--Squad End--> 
                <!--Sidebar Start-->
                <div class="col-lg-4">
                  <div class="sidebar">

                    <!--widget start-->
                    <div class="widget">
                      <h4>Últimas noticias</h4>
                      <div class="top-stories-widget">
                        <div id="top-stories">
                          <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--Slide 1 Start-->
                            <div class="item">
                              <ul class="top-stories">
                                <!--Story Start-->
                                <li class="story-row">
                                  <?php if(isset($noticia->thumb)): ?>  
                                    <div class="ts-thumb"><img src="../images/news/<?php echo e($noticia->thumb); ?>" alt=""> </div>
                                  <?php endif; ?>
                                  <div class="ts-txt">
                                    <h5> <a href="../noticias/<?php echo e($noticia->id); ?>"><?php echo e($noticia->titulo); ?></a> </h5>
                                    <ul class="tsw-meta">
                                      <li><?php echo e($noticia->subtitulo); ?></li>
                                    </ul>
                                  </div>
                                </li>
                                <!--Story End--> 
                              </ul>
                            </div>
                            <!--Slide 1 End--> 
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </div>
                    </div>
                    <!--widget end--> 
                    <!--widget start-->
                    <div class="widget">
                      <h4>Clasificación</h4>
                      <div class="point-table-widget">
                        <table>
                          <thead>
                            <tr>
                              <th title="Posición">P</th>
                              <th>Equipo</th>
                              <th title="Jornadas">J</th>
                              <th>Pts</th>
                            </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($equipo->Puesto); ?></td>
                              <td class="tn"><strong><?php echo e($equipo->Nombre); ?></strong></td>
                              <td><?php echo e($equipo->Jornadas); ?></td>
                              <td><strong><?php echo e($equipo->Puntos); ?></strong></td>
                            </tr>                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <!--widget end-->                     
                    <!--widget start-->
                    <div class="widget">
                      <h4>Sponsors</h4>
                      <ul class="match-sponsors">
                        <li> <a href="https:sticker4life.com" target="_blank"><img src="../images/sticker4life.png" alt=""></a> </li>
                        <!--<li> <a href="#"><img src="images/sitelogos2.png" alt=""></a> </li>
                        <li> <a href="#"><img src="images/sitelogos3.png" alt=""></a> </li>
                        <li> <a href="#"><img src="images/sitelogos4.png" alt=""></a> </li>
                        <li> <a href="#"><img src="images/sitelogos5.png" alt=""></a> </li>
                        <li> <a href="#"><img src="images/sitelogos6.png" alt=""></a> </li>-->
                      </ul>
                    </div>
                    <!--widget start--> 
                  </div>
                </div>
                <!--Sidebar End--> 
              </div>
            </div>
          </div>
          <!--End--> 
        </div>
        <!--team Page End--> 
      </div>
      <!--Main Content End--> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/teamdetail.blade.php ENDPATH**/ ?>