<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="images/fav.png" type="image/png">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/color.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/prettyPhoto.css">
    <title>Futmondo Sage</title>
  </head>
  <body>
    <!--Wrapper Start-->
    <div class="wrapper">
      <!--Header Start-->
      <header id="main-header" class="main-header">
        <!--topbar-->
        <div class="topbar">
          <div class="container">
            <div class="row">
              <div class="col-md-6 col-sm-6">
              </div>
              <div class="col-md-6 col-sm-6">
                <ul class="toplinks">
                  <li class="acctount-btn"> <a href="#">Mi cuenta</a> </li>
                  <li class="search-btn"> <a href="#"><i class="fas fa-search"></i></a> </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <!--topbar end--> 
        <!--Logo + Navbar Start-->
        <div class="logo-navbar">
          <div class="container">
            <div class="row">
              <div class="col-md-2 col-sm-5">
                <div class="logo"><a href="/home"><img src="images/ftmndLogo.png" alt=""></a></div>
              </div>
              <div class="col-md-10 col-sm-7">
                <nav class="main-nav">
                  <ul>
                    <li class="nav-item drop-down">
                      <a href="">Home</a>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Equipos</a>
                      <ul>
                        <li><a href="team-details.html">Team Details</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Jugadores</a>
                      <ul>
                        <li><a href="staff-details.html">Staff Details</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Noticias</a>
                      <ul>
                        <li><a href="news-large.html">News Large</a></li>
                        <li><a href="news-details.html">News Details</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Otras temporadas</a>
                      <ul>
                        <li><a href="page-404.html">Page 404</a></li>
                        <li><a href="page-404-one.html">Page 404 Two</a></li>
                      </ul>
                    </li>
                    <li class="nav-item drop-down">
                      <a href="">Contacto</a>
                      <ul>
                        <li><a href="contact.html">Contact One</a></li>
                      </ul>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <!--Logo + Navbar End--> 
      </header>
      <!--Header End--> 
      <!--Main Slider Start-->
      <div class="inner-banner-header wf100">
        <h1 data-generated="Point Table">Clasificación</h1>
        <div class="gt-breadcrumbs">
          <ul>
            <li> <a href="#" class="active"> <i class="fas fa-home"></i> Home </a> </li>
            <li> <a href="#"> Clasificación </a> </li>
          </ul>
        </div>
      </div>
      <!--Main Slider Start--> 
      <!--Main Content Start-->
      <div class="main-content solidbg wf100">
        <!--team Page Start-->
        <div class="team wf100 p80">
          <!--Start-->
          <div class="point-table">
            <div class="container">
              <div class="row">
                <div class="col-md-12">
                  <div class="point-table-widget">
                    <table>
                      <thead>
                        <tr>
                          <th>P</th>
                          <th>Equipo</th>
                          <th>Jugador</th>
                          <th>P</th>
                          <th>W</th>
                          <th>D</th>
                          <th>L</th>
                          <th>Pts</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td><img src="images/tl-logo1.png" alt=""> <strong>Bethlehem</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>22</td>
                          <td>22</td>
                          <td>4</td>
                          <td>2</td>
                          <td><strong>140</strong></td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td><img src="images/tl-logo2.png" alt=""> <strong>Chirston Battery</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>19</td>
                          <td>19</td>
                          <td>3</td>
                          <td>5</td>
                          <td><strong>138</strong></td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td><img src="images/tl-logo3.png" alt=""> <strong>Charlotte</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>18</td>
                          <td>19</td>
                          <td>2</td>
                          <td>3</td>
                          <td><strong>130</strong></td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td><img src="images/tl-logo4.png" alt=""> <strong>FC Cincinnati</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>17</td>
                          <td>19</td>
                          <td>1</td>
                          <td>2</td>
                          <td><strong>126</strong></td>
                        </tr>
                        <tr>
                          <td>5</td>
                          <td><img src="images/tl-logo5.png" alt=""> <strong>Indy Eleven</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>16</td>
                          <td>19</td>
                          <td>3</td>
                          <td>2</td>
                          <td><strong>110</strong></td>
                        </tr>
                        <tr>
                          <td>6</td>
                          <td><img src="images/tl-logo6.png" alt=""> <strong>Louisville City FC</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>15</td>
                          <td>19</td>
                          <td>4</td>
                          <td>6</td>
                          <td><strong>108</strong></td>
                        </tr>
                        <tr>
                          <td>7</td>
                          <td><img src="images/tl-logo7.png" alt=""> <strong>Nashville SC</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>14</td>
                          <td>19</td>
                          <td>2</td>
                          <td>8</td>
                          <td><strong>106</strong></td>
                        </tr>
                        <tr>
                          <td>8</td>
                          <td><img src="images/tl-logo8.png" alt=""> <strong>NYK Red Bulls</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>13</td>
                          <td>19</td>
                          <td>1</td>
                          <td>9</td>
                          <td><strong>100</strong></td>
                        </tr>
                        <tr>
                          <td>9</td>
                          <td><img src="images/tl-logo9.png" alt=""> <strong>North Carolina</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>12</td>
                          <td>19</td>
                          <td>2</td>
                          <td>10</td>
                          <td><strong>80</strong></td>
                        </tr>
                        <tr>
                          <td>10</td>
                          <td><img src="images/tl-logo10.png" alt=""> <strong>Ottawa Fury</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>11</td>
                          <td>19</td>
                          <td>3</td>
                          <td>11</td>
                          <td><strong>76</strong></td>
                        </tr>
                        <tr>
                          <td>11</td>
                          <td><img src="images/tl-logo5.png" alt=""> <strong>Indy Eleven</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>16</td>
                          <td>19</td>
                          <td>3</td>
                          <td>2</td>
                          <td><strong>110</strong></td>
                        </tr>
                        <tr>
                          <td>12</td>
                          <td><img src="images/tl-logo6.png" alt=""> <strong>Louisville City FC</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>15</td>
                          <td>19</td>
                          <td>4</td>
                          <td>6</td>
                          <td><strong>108</strong></td>
                        </tr>
                        <tr>
                          <td>13</td>
                          <td><img src="images/tl-logo7.png" alt=""> <strong>Nashville SC</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>14</td>
                          <td>19</td>
                          <td>2</td>
                          <td>8</td>
                          <td><strong>106</strong></td>
                        </tr>
                        <tr>
                          <td>14</td>
                          <td><img src="images/tl-logo8.png" alt=""> <strong>NYK Red Bulls</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>13</td>
                          <td>19</td>
                          <td>1</td>
                          <td>9</td>
                          <td><strong>100</strong></td>
                        </tr>
                        <tr>
                          <td>15</td>
                          <td><img src="images/tl-logo9.png" alt=""> <strong>North Carolina</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>12</td>
                          <td>19</td>
                          <td>2</td>
                          <td>10</td>
                          <td><strong>80</strong></td>
                        </tr>
                        <tr>
                          <td>16</td>
                          <td><img src="images/tl-logo10.png" alt=""> <strong>Ottawa Fury</strong></td>
                          <td><strong>Jugador</strong></td>
                          <td>11</td>
                          <td>19</td>
                          <td>3</td>
                          <td>11</td>
                          <td><strong>76</strong></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!--End--> 
        </div>
        <!--team Page End--> 
      </div>
      <!--Main Content End--> 
      <!--Main Footer Start-->
      <footer class="wf100 main-footer">
        <div class="container brtop">
          <div class="row">
            <div class="col-lg-6 col-md-6">
              <p class="copyr"> All Rights Reserved of Sports © 2020, Design & Developed By: <a href="oliverporras.com">OliverPorras</a> </p>
            </div>
            <div class="col-lg-6 col-md-6">
              <ul class="quick-links">
                <li><a href="/home">Home</a></li>
                <li><a href="#">Equipos</a></li>
                <li><a href="#">Jugadores</a></li>
                <li><a href="#">Noticias</a></li>
                <li><a href="#">Contacto</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
      <!--Main Footer End--> 
    </div>
    <!--Wrapper End--> 
    <!-- Optional JavaScript --> 
    <script src="js/jquery-3.3.1.min.js"></script> 
    <script src="js/popper.min.js"></script> 
    <script src="js/bootstrap.min.js"></script> 
<script src="js/mobile-nav.js"></script>  
    <script src="js/owl.carousel.min.js"></script> 
    <script src="js/isotope.js"></script> 
    <script src="js/jquery.prettyPhoto.js"></script> 
    <script src="js/jquery.countdown.js"></script> 
    <script src="js/custom.js"></script>
  </body>
</html><?php /**PATH E:\WampServer\www\master-php\futmondo-laravel\resources\views/clasificacion.blade.php ENDPATH**/ ?>